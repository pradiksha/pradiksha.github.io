#include<stdio.h>
#include<conio.h>
#include<graphics.h>
char side1[7]="111111",side2[7]="000000",boat[3]="00",man=1;
void play1();
void play2();
void game();
int check()
{
  int i,c1=0,c2=0;
  for(i=0;i<3;i++)
   if(side1[i]!='0')
    c1++;
  for(i=3;i<6;i++)
   if(side1[i]!='0')
    c2++;
  if(c2<c1&&c2!=0)
   return 1;
   c1=0;c2=0;
  for(i=0;i<3;i++)
   if(side2[i]!='0')
    c1++;
  for(i=3;i<6;i++)
   if(side2[i]!='0')
    c2++;
  if(c2<c1&&c2!=0)
   return 1;
  if(c2==3&&c1==0)
   {outtextxy(200,90,"GAME COMPLETE");getch();game(); }
  return 0;
 }
void display(int t)
{
  int i,j,t1=0,t2=4,t3;
 char str1[7],ch,str2[7],b[3],print1[10]="[r]-Reset",print2[10]="[g]-Go",print3[11]="[Esc]-Menu";
 if(t&1)
  j=181;
 else
  j=0;
 while(1)
 {
  clearviewport();
  outtextxy(250,25,"PLAY");
 line(0,100,500,100);
 line(0,100,0,400);
 line(0,400,500,400);
 line(500,100,500,400);
 line(0,250,150,250);
 line(350,250,500,250);
 line(150,250,150,400);
 line(350,250,350,400);

 for(i=0;i<6;i++)
  {if(side1[i]!='0')
  {
   if(i<3)
     str1[i]='D';
   else
     str1[i]='M';
  }
  else
  str1[i]=' ';
  }
 str1[i]='\0';
 for(i=0;i<2;i++)
 {
  if(boat[i]!='0')
  {b[i]=boat[i];}
  else b[i]=' ';
  }
 b[i]='\0';
 for(i=0;i<6;i++)
 {if(side2[i]!='0')
  {if(i<3) str2[i]='D';
   else str2[i]='M';
   }
   else str2[i]=' ';
  }
  str2[i]='\0';
 line(34+t1*t2,238,34+t1*t2,228);
 line(34+t1*t2,238,34+t1*t2-5,238-5);
 line(34+t1*t2,238,34+t1*t2+5,238-5);
 outtextxy(30,240,str1);
 outtextxy(380,240,str2);
 outtextxy(152+j,240,b);
 line(150+j,248,170+j,248);
 line(155+j,255,165+j,255);
 line(150+j,248,155+j,255);
 line(170+j,248,165+j,255);
 outtextxy(40,430,print1);
 outtextxy(200,430,print2);
 outtextxy(360,430,print3);
 if(t&1)
 j--;
 else
 j++;
 if((j==181&&!t)||(t&&j==0))
 break;
  }
 outtextxy(200,410,"PRESS [ENTER]");
 getch();
 if(t&1)
   play1();
 else
   play2();
 }
void rules()
{
  printf("\n1.The game will be COMPLETED when you take the monks to the next side");
  printf("\n2.Boat can carry atmost two members and it will carry atleast one member");
  printf("\n3.Boat travels in both side and rule 2 is applied here also");
  printf("\n4.Use left and right arrow to switch between monks and dogs,use down arrow to select the members to go on boat");
  printf("\n5.press G to go,press R to reset,press ESC to goto menu");
  printf("\n6.The game will END when dogs are greater than monks");
  printf("\nPRESS 0 TO GOTO MAIN MENU");
  scanf("%d",&man);
  if(man==0)
    game();
 }
void play2()
{
 int i,j=0,t1=0,t2=4,t3,count=0;
 char str1[7],ch,str2[7],b[3],print1[10]="[r]-Reset",print2[10]="[g]-Go",print3[11]="[Esc]-Menu";

 for(i=0;i<2;i++)
 {
  if(boat[i]=='D')
  {boat[i]='0';for(j=0;j<3;j++) if(side2[j]=='0'){side2[j]='1';break;}}
  else if(boat[i]=='M')
  {boat[i]='0';for(j=3;j<6;j++) if(side2[j]=='0'){side2[j]='1';break;}}
  }
   if(check())
 {outtextxy(200,90,"GAME OVER");getch();game();}

 while(1)
 {
 count=0;
 clearviewport();
 t3=(t1*t2)/8;
 outtextxy(250,25,"PLAY");
 line(0,100,500,100);
 line(0,100,0,400);
 line(0,400,500,400);
 line(500,100,500,400);
 line(0,250,150,250);
 line(350,250,500,250);
 line(150,250,150,400);
 line(350,250,350,400);

 for(i=0;i<6;i++)
  {if(side1[i]!='0')
  {
   if(i<3)
     str1[i]='D';
   else
     str1[i]='M';
  }
  else
  str1[i]=' ';
  }
 str1[i]='\0';
 for(i=0;i<2;i++)
 {
  if(boat[i]!='0')
  {b[i]=boat[i];}
  else b[i]=' ';
  }
 b[i]='\0';
 for(i=0;i<6;i++)
 {if(side2[i]!='0')
  {if(i<3) str2[i]='D';
   else str2[i]='M';
   }
   else str2[i]=' ';
  }
  str2[i]='\0';

 line(384+t1*t2,238,384+t1*t2,228);
 line(384+t1*t2,238,384+t1*t2-5,238-5);
 line(384+t1*t2,238,384+t1*t2+5,238-5);
 outtextxy(30,240,str1);
 outtextxy(380,240,str2);
 outtextxy(333,240,b);
 line(330,248,350,248);
 line(335,255,345,255);
 line(330,248,335,255);
 line(350,248,345,255);
 outtextxy(40,430,print1);
 outtextxy(200,430,print2);
 outtextxy(360,430,print3);
 ch=getch();
 if(ch==77&&t1<10)
 t1+=2;
 else if(ch==75&&t1>0)
 t1-=2;
 else if(ch==27)
 game();
 else if(ch==80)
 {
  t3=(t1*t2)/8;
  for(i=0;i<2;i++)
   if(boat[i]=='0')
    break;
   if(i==2||side2[t3]=='0')
  {outtextxy(200,410,"INVALID INPUT"); getch();continue; }
  for(i=0;i<2;i++)
   {if(boat[i]=='0')
   {boat[i]=str2[t3];break;}
   }
  side2[t3]='0';
  }
 else if(ch=='r')
 {
  for(i=0;i<2;i++)
  {
   int key=0;
   if(boat[i]=='M')
   {boat[i]='0';for(j=3;j<6;j++) if(side2[j]=='0') {side2[j]='1';boat[i]='0';break;}key=1; }
   else if(boat[i]=='D')
   {boat[i]='0';for(j=0;j<3;j++) if(side2[j]=='0') {side2[j]='1';boat[i]='0';break;}key=1; }
  if(key)
    break;
   }
   }
 else if(ch=='g')
 {
  if(check())
 {outtextxy(200,90,"GAME OVER");getch();game();}
  for(i=0;i<2;i++)
   if(boat[i]!='0')
    count++;
  if(count==1||count==2)
  display(1);
  else
  {outtextxy(200,410,"INVALID INPUT"); getch();continue;   }
  }

}
 }
void play1()
{
 int i,j=0,t1=0,t2=4,t3,count=0;
 char str1[7],ch,str2[7],b[3],print1[10]="[r]-Reset",print2[10]="[g]-Go",print3[11]="[Esc]-Menu";
 for(i=0;i<2;i++)
 {
  if(boat[i]=='D')
  {boat[i]='0';for(j=0;j<3;j++) if(side1[j]=='0'){side1[j]='1';break;}}
  else if(boat[i]=='M')
  {boat[i]='0';for(j=3;j<6;j++) if(side1[j]=='0'){side1[j]='1';break;}}
  }
   if(check())
 {outtextxy(200,90,"GAME OVER");getch();game();}

 while(1)
 {
 count=0;
 clearviewport();
 t3=(t1*t2)/8;
 outtextxy(250,25,"PLAY");
 line(0,100,500,100);
 line(0,100,0,400);
 line(0,400,500,400);
 line(500,100,500,400);
 line(0,250,150,250);
 line(350,250,500,250);
 line(150,250,150,400);
 line(350,250,350,400);

 for(i=0;i<6;i++)
  {if(side1[i]!='0')
  {
   if(i<3)
     str1[i]='D';
   else
     str1[i]='M';
  }
  else
  str1[i]=' ';
  }
 str1[i]='\0';
 for(i=0;i<2;i++)
 {
  if(boat[i]!='0')
  {b[i]=boat[i];}
  else b[i]=' ';
  }
 b[i]='\0';
 for(i=0;i<6;i++)
 {if(side2[i]!='0')
  {if(i<3) str2[i]='D';
   else str2[i]='M';
   }
   else str2[i]=' ';
  }
  str2[i]='\0';

 line(34+t1*t2,238,34+t1*t2,228);
 line(34+t1*t2,238,34+t1*t2-5,238-5);
 line(34+t1*t2,238,34+t1*t2+5,238-5);
 outtextxy(30,240,str1);
 outtextxy(380,240,str2);
 outtextxy(152,240,b);
 line(150,248,170,248);
 line(155,255,165,255);
 line(150,248,155,255);
 line(170,248,165,255);
 outtextxy(40,430,print1);
 outtextxy(200,430,print2);
 outtextxy(360,430,print3);
 ch=getch();
 if(ch==77&&t1<10)
 t1+=2;
 else if(ch==75&&t1>0)
 t1-=2;
 else if(ch==27)
 game();
 else if(ch==80)
 {
  t3=(t1*t2)/8;
  for(i=0;i<2;i++)
   if(boat[i]=='0')
    break;
   if(i==2||side1[t3]=='0')
  {outtextxy(200,410,"INVALID INPUT"); getch();continue; }
  for(i=0;i<2;i++)
   {if(boat[i]=='0')
   {boat[i]=str1[t3];break;}
   }
  side1[t3]='0';
  }
 else if(ch=='r')
 {
  for(i=0;i<2;i++)
  {
   int key=0;
   if(boat[i]=='M')
   {boat[i]='0';for(j=3;j<6;j++) if(side1[j]=='0') {side1[j]='1';boat[i]='0';break;}key=1; }
   else if(boat[i]=='D')
   {boat[i]='0';for(j=0;j<3;j++) if(side1[j]=='0') {side1[j]='1';boat[i]='0';break;}key=1; }
  if(key)
    break;
   }
   }
 else if(ch=='g')
 {
  if(check())
 {outtextxy(200,90,"GAME OVER");getch();game();}
  for(i=0;i<2;i++)
   if(boat[i]!='0')
    count++;
  if(count==1||count==2)
  display(0);
  else
  {outtextxy(200,410,"INVALID INPUT"); getch();continue;   }
  }


// line(41,220,41,210);
// line(,,,);
 }
}
void game()
{
 char cho;
 strcpy(side1,"111111");
 strcpy(side2,"000000");
 strcpy(boat,"00");
 clearviewport();
 outtextxy(250,25,"MAIN MENU");
 outtextxy(50,100,"[1]-Play");
 outtextxy(50,115,"[2]-Rules");
 outtextxy(50,130,"[3]-Exit");
// printf("\t\t\t\t\tMAIN MENU\n\n[1]-Play\n[2]-Rules\n[3]-Exit\n");
 cho=getch();
 switch(cho)
 {
   case '1':play1();
	    break;
   case  '2':rules();
	     break;
   case '3':exit(0);
  }
 }

void main()
{
 int x,gd = DETECT ,gm;
 initgraph(&gd,&gm,"C:\\TC\\BGI");
 game();
// play1();
 getch();
 }